import json
import logging
import uuid
import xml.etree.ElementTree as ET
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.services.scope_gate import authorize_action, ScopeDenied
from pydantic import BaseModel, Field

from app.services.scanner_client import submit_job
from app.services.vulnerability_intel import enrich_services

from app.intelligence.providers.base import AIProviderUnavailable
from app.intelligence.providers.factory import get_ai_provider


logger = logging.getLogger("sentinel.assessment")

router = APIRouter(
    prefix="/assessment",
    tags=["Assessment"],
)


class AssessmentRequest(BaseModel):
    project_id: str
    transcript_id: str
    target: str
    requested_by: str = Field(default="human", min_length=1, max_length=30)

    ports: list[int] = Field(
        min_length=1,
        max_length=100,
    )

    excluded_ports: list[int] = Field(
        default_factory=list
    )


# --------------------------------------------------
# NMAP XML PARSING
# --------------------------------------------------

def parse_nmap_xml(xml_text: str) -> list[dict]:

    root = ET.fromstring(xml_text)

    services = []

    for host in root.findall("host"):

        address = host.find("address")

        host_ip = (
            address.get("addr")
            if address is not None
            else None
        )

        for port in host.findall(".//port"):

            state = port.find("state")

            if state is None or state.get("state") != "open":
                continue

            service = port.find("service")

            if service is None:
                continue

            cpes = [
                cpe.text
                for cpe in service.findall("cpe")
                if cpe.text
            ]

            port_id_str = port.get("portid")
            port_id = int(port_id_str) if port_id_str is not None else 0

            services.append({

                "host": host_ip,

                "port": port_id,

                "protocol": port.get("protocol"),

                "name": service.get("name"),

                "product": service.get("product", ""),

                "version": service.get("version", ""),

                "extra_info": service.get("extrainfo", ""),

                "tunnel": service.get("tunnel", ""),

                "cpes": cpes,

            })

    return services


# --------------------------------------------------
# GEMINI CONTEXT
# --------------------------------------------------

def build_gemini_context(target: str, enriched_services: list[dict]) -> dict:
    """Build summary context of discovered services and vulnerabilities for Gemini."""
    open_ports = [s.get("port") for s in enriched_services if s.get("port")]
    cve_count = sum(len(s.get("cve_candidates", [])) for s in enriched_services)
    return {
        "target": target,
        "total_open_services": len(enriched_services),
        "open_ports": open_ports,
        "total_cve_candidates": cve_count,
        "services": enriched_services,
    }




# --------------------------------------------------
# GEMINI INSTRUCTIONS
# --------------------------------------------------

SYSTEM_INSTRUCTION = """
You are SENTINEL's investigation planner.

Your ONLY responsibility is to decide what the assessment should
investigate next.

You do not execute commands, write scripts, or perform tool operations.
You select from the capabilities explicitly supplied by SENTINEL.

OUTPUT:
- Return valid JSON only.
- No markdown.
- No prose outside JSON.
- Group operations by tool.
- Each operation must include a name, target, parameters and reason.
- Return only useful next investigation actions.

REASONING:
- Use supplied evidence, not assumptions.
- A CVE keyword candidate is not a confirmed vulnerability.
- Account for missing versions and configuration uncertainty.
- Avoid repeating completed operations unless justified.
- Prefer targeted investigations over broad repeated scans.
- Prioritise potentially serious findings.
- If no useful investigations remain, use status "ready_for_review".

SAFETY:
- Never exceed the supplied authorised target or port scope.
- Never invent tools, operations, parameters or capabilities.
- Never propose destructive actions, denial of service,
  credential attacks, persistence, lateral movement or exploitation.
- Proposals are requests for SENTINEL to validate, not execution authority.

RESPONSE SCHEMA:

{
  "status": "investigating",
  "assessment_summary": "Brief assessment summary",
  "observations": [
    {
      "title": "Observation title",
      "port": 21,
      "evidence": "Observed evidence",
      "confidence": "high"
    }
  ],
  "actions": [
    {
      "tool": "nmap",
      "action": "service_discovery",
      "target": "authorised_target",
      "parameters": {
        "excluded_ports": []
      },
      "reason": "Evidence-based justification",
      "priority": "high"
    }
  ],
  "completion_reason": null,
  "limitations": []
}

Rules:
- status must be investigating or ready_for_review.
- observations must only describe supplied evidence.
- confidence must be high, medium or low.
- priority must be critical, high, medium or low.
- actions must use only supplied capabilities.
- If ready_for_review, actions must be empty.
- Never repeat completed scans without justification.
- Do not invent vulnerability confirmations.
"""


# --------------------------------------------------
# PLAN PARSING
# --------------------------------------------------

def parse_gemini_plan(response_text: str) -> dict:

    cleaned = response_text.strip()

    if cleaned.startswith("```"):

        lines = cleaned.splitlines()

        if lines and lines[0].startswith("```"):
            lines = lines[1:]

        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]

        cleaned = "\n".join(lines).strip()

        if cleaned.startswith("json"):
            cleaned = cleaned[4:].strip()

    try:

        plan = json.loads(cleaned)

    except json.JSONDecodeError as exc:

        raise ValueError(
            f"Gemini returned invalid JSON: {exc}"
        )

    if not isinstance(plan, dict):
        raise ValueError("Gemini response must be a JSON object")

    if plan.get("status") not in {
        "investigating",
        "ready_for_review",
    }:

        raise ValueError("Invalid assessment status")

    if not isinstance(plan.get("actions"), list):

        raise ValueError("Actions must be a list")

    return plan


# --------------------------------------------------
# PROMPT BUILDER
# --------------------------------------------------

def build_prompt(
    target: str,
    excluded_ports: list[int],
    context: dict,
) -> str:

    capabilities = {

        "nmap": {

            "operations": [

                {

                    "name": "service_discovery",

                    "description": (
                        "Perform the registered full TCP service "
                        "discovery operation, excluding policy-blocked ports."
                    ),

                    "parameters": {

                        "excluded_ports": (
                            "List of excluded TCP ports."
                        ),

                    },

                }

            ]

        }

    }

    prompt_context = {

        "assessment": context,

        "scope": {

            "target": target,

            "excluded_ports": excluded_ports,

        },

        "available_capabilities": capabilities,

        "completed_operations": [

            "initial_full_tcp_service_discovery",

            "service_version_identification",

            "nvd_keyword_enrichment",

        ],

    }

    return (

        "Review the assessment state and determine the next useful "
        "investigation actions.\n"

        "Only use the supplied capabilities.\n"

        "Do not repeat completed operations without justification.\n"

        "Return the required JSON plan.\n\n"

        "ASSESSMENT STATE:\n"

        + json.dumps(
            prompt_context,
            separators=(",", ":"),
            ensure_ascii=False,
        )

    )


# --------------------------------------------------
# ASSESSMENT ENDPOINT
# --------------------------------------------------

@router.post("/run")
def propose_assessment(request: AssessmentRequest, db: Session = Depends(get_db)):
    """Create a proposal for initial discovery; execution requires human approval."""
    from app.schemas.action_proposal import ProposalCreate
    from app.services.action_proposals import create_proposal
    payload=ProposalCreate(
        origin="HUMAN", created_by=request.requested_by,
        tool="nmap", action="service_discovery", target=request.target,
        parameters={"ports":request.ports,"excluded_ports":request.excluded_ports},
        reason="Initial network discovery requested through the assessment workflow.",
        priority="medium",
    )
    return {"assessment_status":"AWAITING_APPROVAL",
            "proposal":create_proposal(db,request.project_id,request.transcript_id,payload)}
