# SENTINEL Human Control Plane v1

Adds persistent, versioned action proposals and one immutable decision per proposal version.

## Apply
Extract this ZIP at the repository root, preserving directory structure. It adds the proposal model, schema, service and API, and updates the model registry and `main.py`.

Then run:

```bash
docker compose up -d --build backend
docker compose logs --tail=100 backend
```

Development startup uses `Base.metadata.create_all()`, creating the new tables without deleting the PostgreSQL volume.

## API
- `POST /projects/{project_id}/transcripts/{transcript_id}/proposals`
- `GET /projects/{project_id}/proposals?transcript_id=...`
- `GET /proposals/{proposal_id}`
- `POST /proposals/{proposal_id}/revise`
- `POST /proposals/{proposal_id}/decision`

A revision creates a new version and supersedes the previous one. Approval is tied to a specific version. This patch records proposals and decisions only; it does not execute actions or issue signatures.

## Security limitation
`created_by`, `edited_by`, and `reviewed_by` are caller-supplied identifiers, not authenticated identities. Keep these endpoints on the trusted development network until authentication/RBAC is implemented. The old scanner direct-execution route remains enabled for now and must be replaced before production.
